This plugin stops commands from being shown in ingame chat.
To be used with servers useing Brenbot.


This is for 4.0 Servers

Put HideCommands.dll in your server folder. And add it to ssgm.ini

;ssgm.ini
[Plugins]
0=HideCommands.dll

CommandsList is a simple tool to generate a list of all brenbot commands. To be used by HideCommands.dll

CommandList.exe Goes in the brenbot folder. Where commands.xml is located.

Run CommandList.exe and copy the config settings generated and place in ssgm.ini.



HideCommands.dll made by Iran
CommandList.exe created by genblacky