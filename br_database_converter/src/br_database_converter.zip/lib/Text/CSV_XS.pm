#line 1 "Text/CSV_XS.pm"
package Text::CSV_XS;

# Copyright (c) 2007-2008 H.Merijn Brand.  All rights reserved.
# Copyright (c) 1998-2001 Jochen Wiedmann. All rights reserved.
# Portions Copyright (c) 1997 Alan Citterman. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the same terms as Perl itself.

################################################################################
# HISTORY
#
# Written by:
#    Jochen Wiedmann <joe@ispsoft.de>
#
# Based on Text::CSV by:
#    Alan Citterman <alan@mfgrtl.com>
#
# Extended by:
#    H.Merijn Brand (h.m.brand@xs4all.nl)
#
############################################################################

require 5.005;

use strict;
use warnings;

use DynaLoader ();
use Carp;

use vars   qw( $VERSION @ISA );
$VERSION = "0.52";
@ISA     = qw( DynaLoader );

sub PV { 0 }
sub IV { 1 }
sub NV { 2 }

# version
#
#   class/object method expecting no arguments and returning the version
#   number of Text::CSV.  there are no side-effects.

sub version
{
    return $VERSION;
    } # version

# new
#
#   class/object method expecting no arguments and returning a reference to
#   a newly created Text::CSV object.

my %def_attr = (
    quote_char		=> '"',
    escape_char		=> '"',
    sep_char		=> ',',
    eol			=> '',
    always_quote	=> 0,
    binary		=> 0,
    keep_meta_info	=> 0,
    allow_loose_quotes	=> 0,
    allow_loose_escapes	=> 0,
    allow_whitespace	=> 0,
    blank_is_undef	=> 0,
    verbatim		=> 0,
    types		=> undef,


    _EOF		=> 0,
    _STATUS		=> undef,
    _FIELDS		=> undef,
    _FFLAGS		=> undef,
    _STRING		=> undef,
    _ERROR_INPUT	=> undef,
    _COLUMN_NAMES	=> undef,
    _BOUND_COLUMNS	=> undef,
    );
my $last_new_err = "";

sub new
{
    $last_new_err =
	"usage: my \$csv = Text::CSV_XS->new ([{ option => value, ... }]);";
    my $proto = shift;
    my $attr  = shift || {};
    my $class = ref ($proto) || $proto	or return;
    for (keys %{$attr}) {
	m/^[a-z]/ && exists $def_attr{$_} and next;
#	croak?
	$last_new_err = "Unknown attribute '$_'";
	return;
	}
    $last_new_err = "";
    my $self  = {%def_attr, %{$attr}};
    bless $self, $class;
    defined $self->{types} and $self->types ($self->{types});
    $self;
    } # new

my %_cache_id = (	# Keep in sync with XS!
    quote_char		=>  0,
    escape_char		=>  1,
    sep_char		=>  2,
    binary		=>  3,
    keep_meta_info	=>  4,
    always_quote	=>  5,
    allow_loose_quotes	=>  6,
    allow_loose_escapes	=>  7,
    allow_double_quoted	=>  8,
    allow_whitespace	=>  9,
    blank_is_undef	=> 10,

    eol			=> 11,	# 11 .. 18
    eol_len		=> 19,
    eol_is_cr		=> 20,
    has_types		=> 21,
    verbatim		=> 22,

    _is_bound		=> 23,	# 23 .. 26
    );

sub _set_attr_C
{
    my ($self, $name, $val) = @_;
    $self->{$name} = $val;
    $self->{_CACHE} or return;
    my @cache = unpack "C*", $self->{_CACHE};
    $cache[$_cache_id{$name}] = defined $val ? unpack "C", $val : 0;
    $self->{_CACHE} = pack "C*", @cache;
    } # _set_attr_C

sub _set_attr_N
{
    my ($self, $name, $val) = @_;
    $self->{$name} = $val;
    $self->{_CACHE} or return;
    my @cache = unpack "C*", $self->{_CACHE};
    my $i = $_cache_id{$name};
    $cache[$i++] = $_ for unpack "C*", pack "N", defined $val ? $val : 0;
    $self->{_CACHE} = pack "C*", @cache;
    } # _set_attr_N

# Accessor methods.
#   It is unwise to change them halfway through a single file!
sub quote_char
{
    my $self = shift;
    @_ and $self->_set_attr_C ("quote_char", shift);
    $self->{quote_char};
    } # quote_char

sub escape_char
{
    my $self = shift;
    @_ and $self->_set_attr_C ("escape_char", shift);
    $self->{escape_char};
    } # escape_char

sub sep_char
{
    my $self = shift;
    @_ and $self->_set_attr_C ("sep_char", shift);
    $self->{sep_char};
    } # sep_char

sub eol
{
    my $self = shift;
    if (@_) {
	my $eol = shift;
	my $eol_len = length $eol;
	$self->{eol} = $eol;
	$self->{_CACHE} or return;
	my @cache = unpack "C*", $self->{_CACHE};
	if (($cache[$_cache_id{eol_len}] = $eol_len) < 8) {
	    $cache[$_cache_id{eol_is_cr}] = $eol eq "\r" ? 1 : 0;
	    }
	else {
	    $cache[$_cache_id{eol_is_cr}] = 0;
	    }
	$eol .= "\0\0\0\0\0\0\0\0";
	$cache[$_cache_id{eol} + $_] = unpack "C", substr $eol, $_, 1 for 0 .. 7;
	$self->{_CACHE} = pack "C*", @cache;
	}
    $self->{eol};
    } # eol

sub always_quote
{
    my $self = shift;
    @_ and $self->_set_attr_C ("always_quote", shift);
    $self->{always_quote};
    } # always_quote

sub binary
{
    my $self = shift;
    @_ and $self->_set_attr_C ("binary", shift);
    $self->{binary};
    } # binary

sub keep_meta_info
{
    my $self = shift;
    @_ and $self->_set_attr_C ("keep_meta_info", shift);
    $self->{keep_meta_info};
    } # keep_meta_info

sub allow_loose_quotes
{
    my $self = shift;
    @_ and $self->_set_attr_C ("allow_loose_quotes", shift);
    $self->{allow_loose_quotes};
    } # allow_loose_quotes

sub allow_loose_escapes
{
    my $self = shift;
    @_ and $self->_set_attr_C ("allow_loose_escapes", shift);
    $self->{allow_loose_escapes};
    } # allow_loose_escapes

sub allow_whitespace
{
    my $self = shift;
    @_ and $self->_set_attr_C ("allow_whitespace", shift);
    $self->{allow_whitespace};
    } # allow_whitespace

sub blank_is_undef
{
    my $self = shift;
    @_ and $self->_set_attr_C ("blank_is_undef", shift);
    $self->{blank_is_undef};
    } # blank_is_undef

sub verbatim
{
    my $self = shift;
    @_ and $self->_set_attr_C ("verbatim", shift);
    $self->{verbatim};
    } # verbatim

# status
#
#   object method returning the success or failure of the most recent
#   combine () or parse ().  there are no side-effects.

sub status
{
    my $self = shift;
    return $self->{_STATUS};
    } # status

sub eof
{
    my $self = shift;
    return $self->{_EOF};
    } # status

# error_input
#
#   object method returning the first invalid argument to the most recent
#   combine () or parse ().  there are no side-effects.

sub error_input
{
    my $self = shift;
    return $self->{_ERROR_INPUT};
    } # error_input

# erro_diag
#
#   If (and only if) an error occured, this function returns a code that
#   indicates the reason of failure

sub error_diag
{
    my $self = shift;
    my @diag = (0, $last_new_err, 0);

    unless ($self && ref $self) {	# Class method or direct call
	$last_new_err and $diag[0] = 1000;
	}
    elsif ($self->isa (__PACKAGE__) && exists $self->{_ERROR_DIAG}) {
	@diag = (0 + $self->{_ERROR_DIAG}, $self->{_ERROR_DIAG});
	exists $self->{_ERROR_POS} and $diag[2] = 1 + $self->{_ERROR_POS};
	}
    my $context = wantarray;
    unless (defined $context) {	# Void context
	$diag[0] and print STDERR "# CSV_XS ERROR: $diag[0] - $diag[1]\n";
	return;
	}
    return $context ? @diag : $diag[1];
    } # error_diag

# string
#
#   object method returning the result of the most recent combine () or the
#   input to the most recent parse (), whichever is more recent.  there are
#   no side-effects.

sub string
{
    my $self = shift;
    return ref $self->{_STRING} ? ${$self->{_STRING}} : undef;
    } # string

# fields
#
#   object method returning the result of the most recent parse () or the
#   input to the most recent combine (), whichever is more recent.  there
#   are no side-effects.

sub fields
{
    my $self = shift;
    return ref $self->{_FIELDS} ? @{$self->{_FIELDS}} : undef;
    } # fields

# meta_info
#
#   object method returning the result of the most recent parse () or the
#   input to the most recent combine (), whichever is more recent.  there
#   are no side-effects. meta_info () returns (if available)  some of the
#   field's properties

sub meta_info
{
    my $self = shift;
    return ref $self->{_FFLAGS} ? @{$self->{_FFLAGS}} : undef;
    } # meta_info

sub is_quoted
{
    my ($self, $idx, $val) = @_;
    ref $self->{_FFLAGS} &&
	$idx >= 0 && $idx < @{$self->{_FFLAGS}} or return;
    $self->{_FFLAGS}[$idx] & 0x0001 ? 1 : 0;
    } # is_quoted

sub is_binary
{
    my ($self, $idx, $val) = @_;
    ref $self->{_FFLAGS} &&
	$idx >= 0 && $idx < @{$self->{_FFLAGS}} or return;
    $self->{_FFLAGS}[$idx] & 0x0002 ? 1 : 0;
    } # is_binary

# combine
#
#   object method returning success or failure.  the given arguments are
#   combined into a single comma-separated value.  failure can be the
#   result of no arguments or an argument containing an invalid character.
#   side-effects include:
#      setting status ()
#      setting fields ()
#      setting string ()
#      setting error_input ()

sub combine
{
    my $self = shift;
    my $str  = "";
    $self->{_FIELDS} = \@_;
    $self->{_FFLAGS} = undef;
    $self->{_STATUS} = (@_ > 0) && $self->Combine (\$str, \@_, 0);
    $self->{_STRING} = \$str;
    $self->{_STATUS};
    } # combine

# parse
#
#   object method returning success or failure.  the given argument is
#   expected to be a valid comma-separated value.  failure can be the
#   result of no arguments or an argument containing an invalid sequence
#   of characters. side-effects include:
#      setting status ()
#      setting fields ()
#      setting meta_info ()
#      setting string ()
#      setting error_input ()

sub parse
{
    my ($self, $str) = @_;

    my $fields = [];
    my $fflags = [];
    $self->{_STRING} = \$str;
    if (defined $str && $self->Parse ($str, $fields, $fflags)) {
	$self->{_ERROR_INPUT} = undef;
	$self->{_FIELDS} = $fields;
	$self->{_FFLAGS} = $fflags;
	$self->{_STATUS} = 1;
	}
    else {
	$self->{_FIELDS} = undef;
	$self->{_FFLAGS} = undef;
	$self->{_STATUS} = 0;
	}
    $self->{_STATUS};
    } # parse

sub column_names
{
    my ($self, @keys) = @_;
    @keys or
	return defined $self->{_COLUMN_NAMES} ? @{$self->{_COLUMN_NAMES}} : undef;

    @keys == 1 && ! defined $keys[0] and
	return $self->{_COLUMN_NAMES} = undef;

    if (@keys == 1 && ref $keys[0] eq "ARRAY") {
	@keys = @{$keys[0]};
	}
    elsif (join "", map { defined $_ ? ref $_ : "" } @keys) {
	croak ($self->SetDiag (3001));
	}

    $self->{_BOUND_COLUMNS} && @keys != @{$self->{_BOUND_COLUMNS}} and
	croak ($self->SetDiag (3003));

    $self->{_COLUMN_NAMES} = [ map { defined $_ ? $_ : "\cAUNDEF\cA" } @keys ];
    @{$self->{_COLUMN_NAMES}};
    } # column_names

sub bind_columns
{
    my ($self, @refs) = @_;
    @refs or
	return defined $self->{_BOUND_COLUMNS} ? @{$self->{_BOUND_COLUMNS}} : undef;

    @refs == 1 && ! defined $refs[0] and
	return $self->{_BOUND_COLUMNS} = undef;

    $self->{_COLUMN_NAMES} && @refs != @{$self->{_COLUMN_NAMES}} and
	croak ($self->SetDiag (3003));

    join "", map { ref $_ eq "SCALAR" ? "" : "*" } @refs and
	croak ($self->SetDiag (3004));

    $self->_set_attr_N ("_is_bound", scalar @refs);
    $self->{_BOUND_COLUMNS} = [ @refs ];
    @refs;
    } # bind_columns

sub getline_hr
{
    my ($self, @args, %hr) = @_;
    $self->{_COLUMN_NAMES} or croak ($self->SetDiag (3002));
    my $fr = $self->getline (@args) or return;
    @hr{@{$self->{_COLUMN_NAMES}}} = @$fr;
    \%hr;
    } # getline_hr

bootstrap Text::CSV_XS $VERSION;

sub types
{
    my $self = shift;
    if (@_) {
	if (my $types = shift) {
	    $self->{_types} = join "", map { chr $_ } @{$types};
	    $self->{types}  = $types;
	    }
	else {
	    delete $self->{types};
	    delete $self->{_types};
	    undef;
	    }
	}
    else {
	$self->{types};
	}
    } # types

1;

__END__

#line 1522
