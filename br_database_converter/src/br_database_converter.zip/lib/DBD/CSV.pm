#line 1 "DBD/CSV.pm"
# -*- perl -*-
#
#   DBD::CSV - A DBI driver for CSV and similar structured files
#
#   This module is currently maintained by
#
#       Jeff Zucker
#       <jeff@vpservices.com>
#
#   The original author is Jochen Wiedmann.
#
#   Copyright (C) 1998 by Jochen Wiedmann
#
#   All rights reserved.
#
#   You may distribute this module under the terms of either the GNU
#   General Public License or the Artistic License, as specified in
#   the Perl README file.
#

require 5.004;
use strict;


require DynaLoader;
require DBD::File;
require IO::File;


package DBD::CSV;

use vars qw(@ISA $VERSION $drh $err $errstr $sqlstate);

@ISA = qw(DBD::File);

$VERSION = '0.22';

$err = 0;		# holds error code   for DBI::err
$errstr = "";		# holds error string for DBI::errstr
$sqlstate = "";         # holds error state  for DBI::state
$drh = undef;		# holds driver handle once initialised

package DBD::CSV::dr; # ====== DRIVER ======

use Text::CSV_XS();
use vars qw(@ISA @CSV_TYPES);

@CSV_TYPES = (
    Text::CSV_XS::IV(), # SQL_TINYINT
    Text::CSV_XS::IV(), # SQL_BIGINT
    Text::CSV_XS::PV(), # SQL_LONGVARBINARY
    Text::CSV_XS::PV(), # SQL_VARBINARY
    Text::CSV_XS::PV(), # SQL_BINARY
    Text::CSV_XS::PV(), # SQL_LONGVARCHAR
    Text::CSV_XS::PV(), # SQL_ALL_TYPES
    Text::CSV_XS::PV(), # SQL_CHAR
    Text::CSV_XS::NV(), # SQL_NUMERIC
    Text::CSV_XS::NV(), # SQL_DECIMAL
    Text::CSV_XS::IV(), # SQL_INTEGER
    Text::CSV_XS::IV(), # SQL_SMALLINT
    Text::CSV_XS::NV(), # SQL_FLOAT
    Text::CSV_XS::NV(), # SQL_REAL
    Text::CSV_XS::NV(), # SQL_DOUBLE
);

@DBD::CSV::dr::ISA = qw(DBD::File::dr);

$DBD::CSV::dr::imp_data_size = 0;
$DBD::CSV::dr::data_sources_attr = undef;

sub connect ($$;$$$) {
    my($drh, $dbname, $user, $auth, $attr) = @_;
    my $dbh = $drh->DBD::File::dr::connect($dbname, $user, $auth, $attr);
    $dbh->{'csv_tables'} ||= {};
    $dbh->{Active} = 1;
    $dbh;
}

package DBD::CSV::db; # ====== DATABASE ======

$DBD::CSV::db::imp_data_size = 0;

@DBD::CSV::db::ISA = qw(DBD::File::db);

sub csv_cache_sql_parser_object {
    my $dbh = shift;
    my $parser = {
            dialect    => 'CSV',
            RaiseError => $dbh->FETCH('RaiseError'),
            PrintError => $dbh->FETCH('PrintError'),
        };
    my $sql_flags  = $dbh->FETCH('csv_sql') || {};
    %$parser = (%$parser,%$sql_flags);
    $parser = SQL::Parser->new($parser->{dialect},$parser);
    $dbh->{csv_sql_parser_object} = $parser;
    return $parser;
}

package DBD::CSV::st; # ====== STATEMENT ======

$DBD::CSV::st::imp_data_size = 0;

@DBD::CSV::st::ISA = qw(DBD::File::st);


package DBD::CSV::Statement;

@DBD::CSV::Statement::ISA = qw(DBD::File::Statement);

sub open_table ($$$$$) {
    my($self, $data, $table, $createMode, $lockMode) = @_;
    my $dbh = $data->{Database};
    my $tables = $dbh->{csv_tables};
    if (!exists($tables->{$table})) {
	$tables->{$table} = {};
    }
    my $meta = $tables->{$table} || {};
    my $csv = $meta->{csv} || $dbh->{csv_csv};
    if (!$csv) {
	my $class = $meta->{class}  ||  $dbh->{'csv_class'}  ||
	    'Text::CSV_XS';
	my %opts = ( 'binary' => 1 );
	$opts{'eol'} = $meta->{'eol'} || $dbh->{'csv_eol'} || "\015\012";
	$opts{'sep_char'} =
	    exists($meta->{'sep_char'}) ? $meta->{'sep_char'} :
		exists($dbh->{'csv_sep_char'}) ? $dbh->{'csv_sep_char'} : ",";
	$opts{'quote_char'} =
	    exists($meta->{'quote_char'}) ? $meta->{'quote_char'} :
		exists($dbh->{'csv_quote_char'}) ? $dbh->{'csv_quote_char'} :
		    '"';
	$opts{'escape_char'} =
	    exists($meta->{'escape_char'}) ? $meta->{'escape_char'} :
		exists($dbh->{'csv_escape_char'}) ? $dbh->{'csv_escape_char'} :
		    '"';
	$csv = $meta->{csv} = $class->new(\%opts);
    }
    my $file = $meta->{file}  ||  $table;
    my $tbl = $self->SUPER::open_table($data, $file, $createMode, $lockMode);
    if ($tbl) {
	$tbl->{'csv_csv'} = $csv;
	my $types = $meta->{types};
	if ($types) {
	    # The 'types' array contains DBI types, but we need types
	    # suitable for Text::CSV_XS.
	    my $t = [];
	    foreach (@{$types}) {
		if ($_) {
		    $_ = $DBD::CSV::CSV_TYPES[$_+6]  ||  Text::CSV_XS::PV();
		} else {
		    $_ = Text::CSV_XS::PV();
		}
		push(@$t, $_);
	    }
	    $tbl->{types} = $t;
	}
	if (!$createMode and !$self->{ignore_missing_table} and $self->command ne 'DROP') {
	    my($array, $skipRows);
	    if (exists($meta->{skip_rows})) {
		$skipRows = $meta->{skip_rows};
	    } else {
		$skipRows = exists($meta->{col_names}) ? 0 : 1;
	    }
	    if ($skipRows--) {
		if (!($array = $tbl->fetch_row($data))) {
		    die "Missing first row";
		}
		$tbl->{col_names} = $array;
		while ($skipRows--) {
		    $tbl->fetch_row($data);
		}
	    }
	    $tbl->{first_row_pos} = $tbl->{fh}->tell();
	    if (exists($meta->{col_names})) {
		$array = $tbl->{col_names} = $meta->{col_names};
	    } elsif (!$tbl->{col_names}  ||  !@{$tbl->{col_names}}) {
		# No column names given; fetch first row and create default
		# names.
		my $a = $tbl->{cached_row} = $tbl->fetch_row($data);
		$array = $tbl->{'col_names'};
		for (my $i = 0;  $i < @$a;  $i++) {
		    push(@$array, "col$i");
		}
	    }
	    my($col, $i);
	    my $columns = $tbl->{col_nums};
	    foreach $col (@$array) {
		$columns->{$col} = $i++;
	    }
	}
    }
    $tbl;
}


package DBD::CSV::Table;

@DBD::CSV::Table::ISA = qw(DBD::File::Table);

sub fetch_row ($$) {
    my($self, $data) = @_;
    my $fields;
    if (exists($self->{cached_row})) {
	$fields = delete($self->{cached_row});
    } else {
	$! = 0;
	my $csv = $self->{csv_csv};
	local $/ = $csv->{'eol'};
	$fields = $csv->getline($self->{'fh'});
	if (!$fields) {
	    die "Error while reading file " . $self->{'file'} . ": $!" if $!;
	    return undef;
	}
    }
    $self->{row} = (@$fields ? $fields : undef);
}

sub push_row ($$$) {
    my($self, $data, $fields) = @_;
    my($csv) = $self->{csv_csv};
    my($fh) = $self->{'fh'};
    #
    #  Remove undef from the right end of the fields, so that at least
    #  in these cases undef is returned from FetchRow
    #
    while (@$fields  &&  !defined($fields->[$#$fields])) {
	pop @$fields;
    }
    if (!$csv->print($fh, $fields)) {
	die "Error while writing file " . $self->{'file'} . ": $!";
    }
    1;
}
*push_names = \&push_row;


1;


__END__

#line 831
