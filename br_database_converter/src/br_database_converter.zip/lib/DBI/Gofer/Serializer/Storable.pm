#line 1 "DBI/Gofer/Serializer/Storable.pm"
package DBI::Gofer::Serializer::Storable;

use strict;
use warnings;

use base qw(DBI::Gofer::Serializer::Base);

#   $Id: Storable.pm 9949 2007-09-18 09:38:15Z timbo $
#
#   Copyright (c) 2007, Tim Bunce, Ireland
#
#   You may distribute under the terms of either the GNU General Public
#   License or the Artistic License, as specified in the Perl README file.

#line 38

use Storable qw(nfreeze thaw);

our $VERSION = sprintf("0.%06d", q$Revision: 9949 $ =~ /(\d+)/o);

use base qw(DBI::Gofer::Serializer::Base);


sub serialize {
    my $self = shift;
    local $Storable::forgive_me = 1; # for CODE refs etc
    my $frozen = nfreeze(shift);
    return $frozen unless wantarray;
    return ($frozen, $self->{deserializer_class});
}

sub deserialize {
    my $self = shift;
    return thaw(shift);
}

1;
