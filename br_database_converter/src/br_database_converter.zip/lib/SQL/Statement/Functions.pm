#line 1 "SQL/Statement/Functions.pm"
##################################
package SQL::Statement::Functions;
##################################
#line 192

use vars qw($VERSION);
$VERSION = '0.1';

#line 218
sub SQL_FUNCTION_CURRENT_DATE {
    my($sec,$min,$hour,$day,$mon,$year) = localtime;
    sprintf "%4s-%02s-%02s", $year+1900,$mon+1,$day;
}

#line 232
sub SQL_FUNCTION_CURRENT_TIME {
    sprintf "%02s::%02s::%02s",(localtime)[2,1,0]
}

#line 245
sub SQL_FUNCTION_CURRENT_TIMESTAMP {
    my($sec,$min,$hour,$day,$mon,$year) = localtime;
    sprintf "%4s-%02s-%02s %02s::%02s::%02s",
            $year+1900,$mon+1,$day,$hour,$min,$sec;
}

#line 264
sub SQL_FUNCTION_CHAR_LENGTH {
    my($self,$sth,$rowhash,@params) = @_;
    return length $params[0];
}

#line 278
sub SQL_FUNCTION_LOWER {
    my($self,$sth,$rowhash,$str) = @_;
    return "\L$str";
}
sub SQL_FUNCTION_UPPER {
    my($self,$sth,$rowhash,$str) = @_;
    return "\U$str";
}

#line 297
sub SQL_FUNCTION_POSITION {
    my($self,$sth,$rowhash,@params) = @_;
    return index($params[1],$params[0]) +1;
}

#line 314
sub SQL_FUNCTION_REGEX {
    my($self,$sth,$rowhash,@params)=@_;
    return 0 unless defined $params[0] and defined $params[1];
    my($pattern,$modifier) = $params[1] =~ m~^/(.+)/([a-z]*)$~;
    $pattern = "(?$modifier:$pattern)" if $modifier;
    return ($params[0] =~ qr($pattern)) ? 1 : 0;
}

#line 334
sub SQL_FUNCTION_SOUNDEX {
    my($self,$sth,$rowhash,@params)=@_;
    require Text::Soundex;
    my $s1 = Text::Soundex::soundex($params[0]) or return 0;
    my $s2 = Text::Soundex::soundex($params[1]) or return 0;
    return ($s1 eq $s2) ? 1 : 0;
}

#line 356
sub SQL_FUNCTION_CONCAT {
    my($self,$sth,$rowhash,@params)=@_;

	my $str = '';
	foreach (@params) {
		return undef unless defined($_);
		$str .= $_;
	}
    return $str;
}

#line 380
sub SQL_FUNCTION_COALESCE {
	my ($obj, $sth, $rowhash, @params) = @_;
#
#	eval each expr in list until a non-null
#	is encountered, then return it
#
	foreach (@params) {
		return $_
			if defined($_);
	}
	return undef;
}

sub SQL_FUNCTION_NVL { return SQL_FUNCTION_COALESCE(@_); }

#line 415
#
#	emulate Oracle DECODE; behaves same as
#	CASE expr WHEN <expr2> THEN expr3
#	WHEN expr4 THEN expr5
#	...
#	ELSE exprN END
#
sub SQL_FUNCTION_DECODE {
	my ($obj, $sth, $rowhash, @params) = @_;
#
#	check param list size, must be at least 4,
#	and even in length
#
	return $obj->do_err('Invalid DECODE argument list!')
		unless ((scalar @params > 3) && ($#params & 1 == 1));
#
#	eval first argument, and last argument,
#	then eval and compare each succeeding pair of args
#	be careful about NULLs!
#
	my $lhs = shift @params;
	my $default = pop @params;
	return $default unless defined($lhs);
	my $lhs_isnum = is_number($lhs);

	while (@params) {
		my $rhs = shift @params;
		shift @params,
		next
			unless defined($rhs);
		return shift @params
			if ((is_number($rhs) && $lhs_isnum && ($lhs == $rhs)) ||
				($lhs eq $rhs));
		shift @params;
	}
	return $default;
}

sub is_number {
	my $v = shift;
    return ($v=~/^([+-]?|\s+)(?=\d|\.\d)\d*(\.\d*)?([Ee]([+-]?\d+))?$/);
}

#line 471
sub SQL_FUNCTION_REPLACE {
    my($self,$sth,$rowhash,@params)=@_;
    return undef unless defined $params[0] and defined $params[1];

	eval "\$params[0]=~$params[1]";
    return $@ ? undef : $params[0];
}

sub SQL_FUNCTION_SUBSTITUTE { return SQL_FUNCTION_REPLACE(@_); }


sub SQL_FUNCTION_SUBSTR {
    my($self,$sth,$rowhash,@params)=@_;
    my $string = $params[0] || '';
    my $start  = $params[1] || 0;
    my $offset = $params[2] || length $string;
    my $value = '';
       $value = substr($string,$start-1,$offset)
       if length $string >= $start-2+$offset;
}

#line 540

sub SQL_FUNCTION_IMPORT {
    my($self,$sth,$rowhash,@params)=@_;
    if (ref $params[0] eq 'ARRAY') {
        my $type =  ref $params[0]->[0];
        return $params[0] unless $type and $type eq 'HASH';
        my @tbl=();
        for my $row(@{$params[0]}) {
            my @cols = sort keys %$row;
            push @tbl, \@cols unless @tbl;
            push @tbl, [@$row{@cols}];
        }
        return \@tbl;
    }
    my $tmp_sth = $params[0];
#   my @cols = map{$_->name} $tmp_sth->{f_stmt}->columns if $tmp_sth->{f_stmt};
   my @cols;
    @cols = @{ $tmp_sth->{NAME} } unless @cols;
#    push @{$sth->{org_names}},$_ for @cols;
    my $tbl  = [ \@cols ];
    while (my @row=$tmp_sth->fetchrow_array) {
        push @$tbl, \@row;
    }
    return $tbl;
}

# RUN()
#
# takes the name of a file containing SQL statements, runs the statements
# see SQL::Parser for details
#
sub SQL_FUNCTION_RUN {
    my($self,$sth,$rowhash,$file)=@_;
    my @params = $sth->{f_stmt}->params;
       @params = () unless @params;
    local *IN;
    open(IN,'<',$file) or die "Couldn't open SQL File '$file': $!\n";
    my @stmts = split /;\s*\n+/,join'',<IN>;
    $stmts[-1] =~ s/;\s*$//;
    close IN;
    my @results = ();
    for my $sql(@stmts) {
        my $tmp_sth = $sth->{Database}->prepare($sql);
        $tmp_sth->execute(@params);
        next unless $tmp_sth->{NUM_OF_FIELDS};
        push @results, $tmp_sth->{NAME} unless @results;
        while (my @r=$tmp_sth->fetchrow_array) { push @results, \@r }
    }
    #use Data::Dumper; print Dumper \@results and exit if @results;
    return \@results;
}

#line 615
1;
